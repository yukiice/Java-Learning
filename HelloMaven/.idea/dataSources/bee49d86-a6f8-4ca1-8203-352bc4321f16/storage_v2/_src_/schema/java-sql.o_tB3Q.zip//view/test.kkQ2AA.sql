create definer = root@localhost view test as
select `java-sql`.`students`.`id`   AS `id`,
       `java-sql`.`students`.`name` AS `name`,
       `java-sql`.`students`.`age`  AS `age`
from `java-sql`.`students`;

